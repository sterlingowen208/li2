package main

import (
	"context"
	"fmt"
	"log"
	"time"

	"github.com/twmb/franz-go/pkg/kadm"
	"github.com/twmb/franz-go/pkg/kgo"
)

func main() {
	brokers := []string{"localhost:9092"}
	topic := "test-topic"

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	cl, err := kgo.NewClient(
		kgo.SeedBrokers(brokers...),
		kgo.ConsumeTopics(topic),
	)
	if err != nil {
		log.Fatalf("Ошибка создания клиента Kafka: %v", err)
	}
	defer cl.Close()

	// === СОЗДАНИЕ ТОПИКА ===
	adm := kadm.NewClient(cl)
	resp, err := adm.CreateTopic(ctx, 1, 1, nil, topic)
	if err != nil {
		log.Fatalf("Ошибка при создании топика: %v", err)
	}
	if resp.Err != nil {
		fmt.Printf("Примечание: %v\n", resp.Err)
	} else {
		fmt.Printf("Топик '%s' создан\n", topic)
	}
	// =======================

	fmt.Println("=== 1. Отправка сообщения ===")

	record := &kgo.Record{
		Topic: topic,
		Value: []byte("Привет из Go в 2026! franz-go работает корректно."),
	}

	err = cl.ProduceSync(ctx, record).FirstErr()
	if err != nil {
		log.Fatalf("Ошибка отправки сообщения: %v", err)
	}
	fmt.Println("Сообщение успешно отправлено!")

	// ... остальной код чтения остаётся без изменений
}
